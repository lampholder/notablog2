# This python file uses the followin encoding: utf-8

import cherrypy

class Blog:

  def __init__(self):
    PAGE = 'templates/index.template'
    ENTRY = 'templates/entry.template'

    self._page_template = file(PAGE)
    self._entry_template = file(ENTRY)
    self._entries_path = './entries/'

  def _get_entries(self):
    return glob.glob(os.path.join(self._entries_path, '*.entry'))

  def _get_entry(self, filename):
    return 'hi!'

  @cherrypy.expose
  def index(self):
    return self._get_entries()

